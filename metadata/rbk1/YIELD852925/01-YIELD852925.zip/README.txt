
Broadbalk Wheat Experiment mean annual grain and straw yields 1852-1925
=======================================================================

[https://doi.org/10.23637/rbk1-1796346264-1](10.23637/ERADOC-1-34916�)

**Version**
:    1

**Published**
:    2021

**Publisher**
:    Electronic Rothamsted Archive, Rothamsted Research

**Keywords**
:    Broadbalk long-term experiment, wheat, Rothamsted Research, straw, grain yield, arable farming, long term experiments

YOU MUST CITE AS:�Rothamsted Research (2021). Broadbalk Wheat Experiment annual grain and straw yields 1852-1925. Electronic Rothamsted Archive, Rothamsted Research, Harpenden, UK 10.23637/rbk1-1796346264-1

## Description
*Note* the included Excel file: _*01-BKyield1852-1925.xlsx*_ contains the same data as the below CSV files. The Excel file contains each of the below CSV files as an Excel worksheet and is provided for users who prefer Excel over CSV.
### Contents

|File|Dataset Name|Description|
|----|------------|-----------|
|crop_data.csv|crop yield data|The main data table containing mean annual grain and straw yield data for all strips (plots) and details of all fertilizer and manure treatments, 1852-1925. Also other agronomic information, including sowing and harvest dates, amount, type and date of application of treatments, and winter wheat cultivars. The strips extended the whole length of the field; each strip tested a different fertilizer or manure treatment. Most strips were divided into two or more sub-plots for many of the years 1852-1925. Annual yield data for each strip (plot) is the mean of all sub-plots, except when the fertilizer treatments were different (plots 9a and 9b,  15a and 15b, notes 6-7). If a sub-plot received a different treatment for one year it was excluded from the mean (notes 2-4). See notes and plan for full details. |
|fym_factor_data.csv|FYM treatment factor level description|Describes the FYM (farmyard manure) treatment factor levels used|
|rape_cake_factor_data.csv|Rape cake treatment factor level description|Describes the rape cake (a type of organic manure) treatment factor levels used |
|n_factor_data.csv|N fertilizer treatment factor level descriptions|Describes the different N (nitrogen) fertilizer  treatment factor levels used|
|p_factor_data.csv|P fertilizer treatment factor level descriptions|Describes the P (phosphorus) fertilizer  treatment factor levels used|
|k_factor_data.csv|K fertilizer treatment factor level descriptions|Describes the K (potassium) fertilizer  treatment factor levels used|
|na_factor_data.csv|Na fertilizer treatment factor level descriptions|Describes the Na (sodium) fertilizer  treatment factor levels used|
|mg_factor_data.csv|Mg fertilizer treatment factor level descriptions|Describes the Mg (magnesium) fertilizer  treatment factor levels used|
|notes_data.csv|Notes|Additional explanatory notes for records in the crop_data table, including details of sub-plots. |

### Abstract
Mean annual grain and straw yields for each treatment strip of the Broadbalk Wheat Experiment, 1852-1925. Also other agronomic information, including sowing and harvest dates, amount, type and date of application of treatments, and winter wheat cultivars.
### Methods
The treatment strips (plots) extend the whole length of the field, each testing a different fertilizer or manure treatment. In some years, the strips were divided into two or more sub-plots. Annual yield data presented here for each strip is the mean of all sub-plots, except when the fertilizer treatments were different (plots 9a and 9b, 15a and 15b, selected years), or if a sub-plot received a different treatment for one year, when it was excluded from the mean. 
Most strips were divided into two parallel sub-plots (a and b) 1852-1983; these halves were combined to make one strip in 1894. Strips 5-8, 15 & 16 were divided into top (T) and bottom (B) sub-plots for most years 1894-1925, T and B receiving the same fertilizer treatments. All other strips (except 20) were divided into T and B sub-plots 1912-1925. In some years the strips were divided into three or four sub-plots, of varying sizes. See 'Broadbalk plan and cropping 1852-1925' for full details. 
Yield data from 1844-1851 is not included, as the fertilizer treatments were not fully established until 1852.
### Technical Info
Wheat grain and straw yields have been recorded every year since the experiment began, with the first harvest in 1844 (the crop was sown in autumn 1843). Dried grain and straw samples have also been kept for chemical analysis since 1844; these are preserved in the Rothamsted Sample Archive. Yields are expressed at field moisture content, 
approximately 85% dry matter.
### Other
Individual sub-plot data can be accessed from the BKYIELD dataset in the e-RA database.
### Provenance
Mean yields are derived from the individual sub-plot yields of grain and straw in the BKYIELD dataset in the e-RA database. The Broadbalk 'White Books' , held in the Rothamsted Library Archive, were used to check the treatments  applied to the sub-plots.
### Quality
In accordance with the Joint Code of Practice for Research at Rothamsted, data processing in e-RA follow rigorous standard operating procedures to ensure the quality and correctness of data collected in the field through to depositing in the e-RA database. To ensure quality control during data inputting, the data sets were typed on two separate occasions (double data entry). During the second typing (verification) the data values were compared with those typed on the earlier occasion, and any discrepancies were resolved before verification continued. This procedure also set out how to handle situations where the written records were illegible or ambiguous. This procedure avoided visual checking of data, which can be very inaccurate. Once the data were entered into e-RA, they were independently back-checked against the original data sheets.

### Authors
|Name|ORCID|Affiliation|
|----|-----|-----------|

### Contributor Roles
|Name|ORCID|Role|Affiliation|
|----|-----|----|-----------|
|Margaret Glendining|<https://orcid.org/0000-0002-6466-4629>|Data Curator|Computational and Analytical Sciences, Rothamsted Research|
|Andrew Macdonald|<https://orcid.org/0000-0002-1785-4892>|Project Leader|Sustainable Agricultural Sciences, Rothamsted Research|
|Paul Poulton|<https://orcid.org/0000-0002-5720-064X>|Researcher|Sustainable Agricultural Sciences, Rothamsted Research|
|Sarah Perryman|<https://orcid.org/0000-0002-0056-2754>|Data Curator|Computational and Analytical Sciences, Rothamsted Research|
|Nathalie Castells-Brooke|<https://orcid.org/0000-0003-0168-6254>|Data Manager|Computational and Analytical Sciences, Rothamsted Research|
|Richard Ostler|<https://orcid.org/0000-0002-1434-9495>|Project Manager|Computational and Analytical Sciences, Rothamsted Research|

### Conditions of Use
**Rights Holder**
:    Rothamsted Research

**Licence**
:    This dataset is available under a�Creative Commons Attribution Licence (4.0). [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

**Cite this Dataset**
:    YOU MUST CITE AS:�Rothamsted Research (2021). Broadbalk Wheat Experiment annual grain and straw yields 1852-1925. Electronic Rothamsted Archive, Rothamsted Research, Harpenden, UK 10.23637/rbk1-1796346264-1

**Conditions of Use**
:    Rothamsted relies on the integrity of users to ensure that Rothamsted Research receives suitable acknowledgment as being the originators of these data. This enables us to monitor the use of each dataset and to demonstrate their value. Please send us a link to any publication that uses this Rothamsted data.

### Funding

**Funder name**
:    [Biotechnology and Biological Sciences Research Council](http://dx.doi.org/10.13039/501100000268)

**Award**
:    BBS/E/C/00005189 - The Rothamsted Long-Term Experiments including Sample Archive and e-RA database

**Award info**
:    [http://dx.doi.org/10.13039/501100000268](Biotechnology and Biological Sciences Research Council)

**Funder name**
:    [Biotechnology and Biological Sciences Research Council](http://dx.doi.org/10.13039/501100000268)

**Award**
:    BBS/E/C/000J0300 - The Rothamsted Long - Term Experiments - National Capability

**Award info**
:    [http://dx.doi.org/10.13039/501100000268](Biotechnology and Biological Sciences Research Council)


### Supplementary materials

|Resource|link|description|
|-------------|------------|-----------|
|Glendining and Poulton (2021) |[https://doi.org/10.23637/rbk1-sup-1534342858-02](https://doi.org/10.23637/rbk1-sup-1534342858-02)|Broadbalk Wheat Experiment plan 1852-1925 and cropping details|
|Rothamsted Research (2021)|[https://doi.org/10.23637/rbk1-FertTreats-02](https://doi.org/10.23637/rbk1-FertTreats-02)|Broadbalk Wheat Experiment fertilizer and manure treatments 1852-2021|
|Rothamsted (1966)|[https://doi.org/10.23637/ERADOC-1-191�](https://doi.org/10.23637/ERADOC-1-191�)|Details of the Classical and Long-term experiments up to 1967|
|Johnston and Garner (1969)|[https://doi.org/10.23637/ERADOC-1-34916�](https://doi.org/10.23637/ERADOC-1-34916�)|Broadbalk: Historical Introduction. |

### Data Dictionary

###crop_data

####crop yield data

The main data table containing mean annual grain and straw yield data for all strips (plots) and details of all fertilizer and manure treatments, 1852-1925. Also other agronomic information, including sowing and harvest dates, amount, type and date of application of treatments, and winter wheat cultivars. The strips extended the whole length of the field; each strip tested a different fertilizer or manure treatment. Most strips were divided into two or more sub-plots for many of the years 1852-1925. Annual yield data for each strip (plot) is the mean of all sub-plots, except when the fertilizer treatments were different (plots 9a and 9b,  15a and 15b, notes 6-7). If a sub-plot received a different treatment for one year it was excluded from the mean (notes 2-4). See notes and plan for full details. 

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|harvest_year|Year in which crop harvested|year|default|https://schema.org/Date|Year in which the crop was harvested. It will generally have been sown the previous year.|
|plot|Plot (also known as strip)|string|default|http://purl.obolibrary.org/obo/STATO_0000447|Original plots called strips, which extended the whole length of the field|
|sub_plot|Sub-plot|string|default|http://purl.obolibrary.org/obo/STATO_0000448|Plots 9 and 15 were divided into sub-plots a and b which received different fertilizer treatments, for limited numbers of years (plot 9 1852-93; plot 15 1852-72). They are then shown as as plots 9 and 15 respectively.  Sub-plots are only shown separately if they are given different fertilizer treatments.|
|fertilizer_code|fertilizer and manure treatment code|string|default|https://schema.org/name|Code describing the fertilizer or manure applied in that harvest year|
|fym_factor_level|FYM factor level|string|default|https://schema.org/name|Code for the FYM factor level applied in that harvest year|
|fym_date|Date FYM applied|date|default|https://schema.org/Date|Date FYM applied, usually in the autumn|
|rape_cake_factor_level|Rape Cake factor level|string|default|https://schema.org/name|Code for the rape cake factor level applied in that harvest year|
|rape_cake_date|Date rape cake applied|date|default|https://schema.org/Date|Date rape cake applied, usually in the autumn|
|n_factor_level|N factor level|string|default|https://schema.org/name|Code for the inorganic nitrogen fertilizer factor level applied in that harvest year|
|n_timing|Timing of fertilizer N|string|default||When inorganic nitrogen fertilizer was applied: either all in autumn (autumn), all in spring (spring) or a combination of autumn and spring (autumn_&_spring). In general, all ammonium sulphate applied as follows: 1852-1877 in autumn except stip 15; 1878-1883 in spring except strip 15; 1884-1925 24kgN applied in autumn, remainder in spring except strip 15. In general, all sodium nitrate applied as follows: 1852-1866 in autumn; 1867-1925 in spring one application except strip 16 applied as two equal amounts since 1899, from six days to six weeks apart.|
|autumn_n_kg/ha|Fertilizer N applied in autumn|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Total inorganic nitrogen fertilizer treatments applied in the autumn to this crop. This does not include N applied in other treatments (FYM or rape cake).|
|autumn_n_date|Date fertilizer N applied in autumn|date|default|https://schema.org/Date|Date inorganic fertilizer nitrogen applied in the autumn|
|spring1_n_kg/ha|First spring fertilizer N amount|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Amount of N in first application of inorganic nitrogen fertilizer applied in the spring to this crop. This may be the only application. This does not include N in FYM or rape cake.|
|spring1_n_date|First spring fertilizer N date|date|default|https://schema.org/Date|Date first application of inorganic nitrogren fertilizer applied in the spring. There may not be a second application in the spring.|
|spring2_n_kg/ha|Second spring fertilizer N amount|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Amount of N in second application of inorganic nitrogen fertilizer applied in the spring to this crop. Plot 16 only, all other plots received only one spring N application. This does not include N in FYM or rape cake.|
|spring2_n_date|Second spring fertilizer N date|date|default|https://schema.org/Date|Date second application of inorganic nitrogen fertilizer applied in the spring. Plot 16 only.|
|total_fertilizer_n_amount|Total inorganic nitrogen fertilizer N amount|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Total inorganic nitrogen fertilizer applied in autumn and spring to this crop. This does not include N in FYM or rape cake|
|p_factor_level|P factor level|string|default|https://schema.org/name|Code for the phosphorous fertilizer factor level applied in that harvest year|
|p_date|P fertilizer application date|date|default|https://schema.org/Date||
|k_factor_level|K factor level|string|default|https://schema.org/name|Code for the potassium fertilizer factor level applied in that harvest year|
|k_date|K fertilizer application date|date|default|https://schema.org/Date||
|na_factor_level|Na factor level|string|default|https://schema.org/name|Code for the sodium fertilizer factor level applied in that harvest year|
|na_date|Na fertilizer application date|date|default|https://schema.org/Date||
|mg_factor_level|Mg factor level|string|default|https://schema.org/name|Code for the magnesium fertilizer factor level applied in that harvest year|
|mg_date|Mg fertilizer application date|date|default|https://schema.org/Date||
|sow_date|Sowing date|date|default|https://schema.org/Date|Date the crop was sown, generally in the autumn in the year before harvest|
|harvest_date|Harvest date|date|default|https://schema.org/Date|Date the crop was harvested|
|cultivar|Wheat cultivar|string|default|http://aims.fao.org/aos/agrovoc/c_8157|Wheat cultivar or variety|
|area_ha|Cropped area|number|default|http://aims.fao.org/aos/agrovoc/c_330588|Area of plot which was cropped, excluding fallow sub-plots or other parts of the plot which were excluded as shown in notes. Most  plots were originally 0.135 or 0.27 ha, reduced to 0.10 or 0.20 ha in 1894 when paths were added.|
|grain|Grain yield|number|default|http://aims.fao.org/aos/agrovoc/c_10176|Harvested wheat grain yield at field moisture content (approximately 85% dry matter, but this was not measured).|
|straw|Straw yield|number|default|http://aims.fao.org/aos/agrovoc/c_10176|Harvested wheat straw yield at field moisture content (approximately 85% dry matter, but this was not measured). This does not include stubble.|
|note|Note|string|default||Whether notes are applied or not|


###fym_factor_data

####FYM treatment factor level description

Describes the FYM (farmyard manure) treatment factor levels used

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Amount of FYM applied|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which FYM was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form in which the factor level treatment was applied|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|


###k_factor_data

####K fertilizer treatment factor level descriptions

Describes the K (potassium) fertilizer  treatment factor levels used

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Total inorganic potassium (K) fertilizer which was applied to this crop as a treatment factor. This does not include K in FYM or rape cake.|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which the K was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form of inorganic K fertilizer applied|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|


###mg_factor_data

####Mg fertilizer treatment factor level descriptions

Describes the Mg (magnesium) fertilizer  treatment factor levels used

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Total inorganic magnesium (Mg) fertilizer which was applied to this crop as a treatment factor. This does not include Mg in FYM or rape cake.|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which the Mg was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form of inorganic magnesium fertilizer applied|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|


###n_factor_data

####N fertilizer treatment factor level descriptions

Describes the different N (nitrogen) fertilizer  treatment factor levels used

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Total inorganic nitrogen (N) fertilizer which was applied to this crop as a treatment factor. This does not include N in FYM or rape cake. Note at different periods of the experiment N was variously applied in autumn or spring and applied in a single application or split applications. Timings and amounts of N applied are indicated in the crop_data table in the fields autumn_n_kg, autumn_n_date, spring1_n_kg, spring1_n_date, spring2_n_kg and spring2_n_date|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which the N was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form of inorganic N fertilizer applied; either ammonium sulfate or sodium nitrate|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|


###na_factor_data

####Na fertilizer treatment factor level descriptions

Describes the Na (sodium) fertilizer  treatment factor levels used

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Total inorganic sodium (Na) fertilizer which was applied to this crop as a treatment factor. This does not include Na in FYM, rape cake or sodium nitrate.|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which the Na was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form of inorganic Na fertilizer applied|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|


###notes_data

####Notes

Additional explanatory notes for records in the crop_data table, including details of sub-plots. 

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|note_id|Note identification|string|default||Note number|
|description|Description|string|default|http://schema.org/description|Additional explanatory notes for records in the crop_data table|


###p_factor_data

####P fertilizer treatment factor level descriptions

Describes the P (phosphorus) fertilizer  treatment factor levels used

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Total inorganic phosphorus (P) fertilizer which was applied to this crop as a treatment factor. This does not include P in FYM or rape cake.|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which the P fertilizer was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form of inorganic P fertilizer applied|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|


###rape_cake_factor_data

####Rape cake treatment factor level description

Describes the rape cake (a type of organic manure) treatment factor levels used 

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|https://schema.org/description|A description of the factor level|
|factor_level_name|Factor level name|string|default|http://purl.obolibrary.org/obo/STATO_0000265|The name for a factor level|
|years|Years|string|default||The year range for when the factor level was used|
|treatment_factor|Treatment factor|string|default|http://purl.obolibrary.org/obo/NCIT_C164385|The label for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor|
|amount|Amount|number|default|https://schema.org/QuantitativeValue|Amount of rape cake applied|
|amount unit|Amount unit|string|default|https://schema.org/unitText|Units in which rape cake was applied each year|
|n_amount|N amount|number|default|https://schema.org/QuantitativeValue|Amount of nitrogen which was applied in the rape cake application each year|
|n_amount_unit|N amount unit|string|default|https://schema.org/unitText|Units in which the N in the rape cake was applied each year|
|frequency|Frequency|string|default|https://schema.org/repeatFrequency|The frequency at which the factor level treatment was applied|
|treatment_form|Treatment form|string|default|http://purl.obolibrary.org/obo/CHEBI_33287|The form in which the factor level treatment was applied|
|treatment_form_rdfType|Treatment form rdfType|string|default|https://schema.org/identifier|A controlled vocabulary URI for the treatment factor level form|

