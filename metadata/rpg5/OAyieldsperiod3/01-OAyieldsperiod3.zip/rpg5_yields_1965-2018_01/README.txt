
Park Grass Hay Yields 1965-2018
===============================

[10.23637/rpg5-yields1965-2018-01 ](https://doi.org/10.23637/rpg5-yields1965-2018-01 )

**Version**
:    1

**Published**
:    2021

**Publisher**
:    Electronic Rothamsted Archive, Rothamsted Research

**Keywords**
:    liming, long term experiments, fertilizer, Park grass long-term experiment, permanent grassland, Rothamsted Research, soil pH, crop yield, fertilizer

YOU MUST CITE AS:�Perryman S.A.M. & Ostler R.J. (2021). Park Grass hay yields 1965-2018. Electronic Rothamsted Archive, Rothamsted Research 10.23637/rpg-yields1965-2018

## Description
*Note* the included Excel file: _*rpg5_yields_1965-2018_01.xlsx*_ contains the same data as the below CSV files. The Excel file contains each of the below CSV files as an Excel worksheet and is provided for users who prefer Excel over CSV.
### Contents

|File|Dataset Name|Description|
|----|------------|-----------|
|crop_data.csv|Crop yield data|Data table containing crop yield data for all plots and all treatments, 1965-2018. Includes details of all lime and fertilizer treatments applied. |
|liming_factor_data.csv|Liming treatment factor level descriptions|Describes the different liming treatment factors, showing the total amounts applied over the experiment required to produce desired pH levels for different sub-plots a-d.|
|n_factor_data.csv|N treatment factor level descriptions|N treatments applied 1965-2018; this describes the nitrogen treatment factors.|
|p_factor_data.csv|P treatment factor level descriptions|P treatments applied 1965-2018; this describes the phosphorous treatment factors.|
|k_factor_data.csv|K treatment factor level descriptions|K treatments applied 1965-2018; this describes the potassium treatment factors.|
|mg_factor_data.csv|Mg treatment factor level descriptions|Mg treatments applied 1965-2018; this describes the magnesium treatment factors.|
|na_factor_data.csv|Na treatment factor level descriptions|Na treatments applied 1965-2018; this describes the sodium treatment factors.|
|si_factor_data.csv|Si treatment factor level descriptions|Si treatments applied 1965-2018; this describes the silicon treatment factors.|
|fym_factor_data.csv|FYM treatment factor level descriptions|FYM treatments applied 1965-2018; this describes the farm yard manure treatment factors.|
|fm_factor_data.csv|FM treatment factor level descriptions|FM treatments applied 1965-2002; this describes the fish meal treatment factors.|
|pm_factor_data.csv|PM treatment factor level descriptions|PM treatments applied 2003-2018; this describes the poultry manure treatment factors.|
|notes_data.csv|Notes|Additional explanatory notes for records in the crop_data table|

### Abstract
This dataset contains the yields of hay (t/ha), for both the 1st and 2nd cuts, harvested from Park Grass Hay Experiment since 1965-2018. Details of the fertilizer, lime treatments and harvest dates are also included. In 1965, a new liming regime was introduced with four sub-plots per plot (a. at pH 7, b. at pH 6, c. at pH 5 and d. un-limed). Yields are provided for all fertiliser treatment plots and sub-plots (except for plots 5 and 6 cd, which were used for micro-plot experiments). Yields are expressed as t/ha at 100% dry matter. Variations in yield reflect the various fertilizer treatments and liming regimes, as well as the local weather and atmospheric inputs.
### Methods
This experiment tests the effects of inorganic fertilizers, organic fertilizers and soil pH (which varies on sub-plots as a result of liming) on yields of hay. See Third Design Period 1965- for detail. The yields  are estimated from strips cut from the centre of each plot  with a forage harvester (since 1960). After the first cut in mid-June the remainder of each plot is mown and made into hay, continuing earlier management and ensuring return of seed. For the second cut, the whole of each plot is cut with a forage harvester.
### Technical Info
Hay yields have been recorded every year since the Park Grass experiment began, with the first harvest in 1856. Dried samples have also been kept since 1856 and these are preserved in the Rothamsted Sample Archive.
### Other
Park Grass was initiated to investigate the ways of improving the yield of hay by the application of inorganic fertilizers and organic manure. With time, the soil became more acidic and in 1903 plots had been halved and the effects of lime tested. From 1965 a new liming regime was initiated with four sub-plots, three receiving lime to maintain soil pH (0-23cm depth) at pH 7, 6, and 5 on sub-plots a, b and c. Sub-plot d does not receive any lime.
The change in harvest method in 1960 means recorded yields of dry matter are larger than previously as fewer losses occur. The previous harvest method estimated yield by weighing the produce from the whole field. See reference by Bowley et al (2017).
### Provenance
Individual plot yields are derived from the PGHAYEQUIV dataset in the e-RA database and were checked with the published yields in the annual Rothamsted Yield Books.

This Frictionless dataset of combined yield and treatment data was compiled by S. Perryman & R. Ostler and checked by M. Glendining September 2021.
### Quality
In accordance with the Joint Code of Practice for Research at Rothamsted, data processing in e-RA follow rigorous standard operating procedures to ensure the quality and correctness of data collected in the field through to depositing in the e-RA database. To ensure quality control during data inputting, the data sets were typed on two separate occasions (double data entry). During the second typing (verification) the data values were compared with those typed on the earlier occasion, and any discrepancies were resolved before verification continued. This procedure also set out how to handle situations where the written records were illegible or ambiguous. This procedure avoided visual checking of data, which can be very inaccurate. Once the data were entered into e-RA, they were independently back-checked against the original data sheets.

### Authors
|Name|ORCID|Affiliation|
|----|-----|-----------|
|Sarah Perryman|<https://orcid.org/0000-0002-0056-2754>|Computational and Analytical Sciences, Rothamsted Research|
|Richard Ostler|<https://orcid.org/0000-0002-1434-9495>|Computational and Analytical Sciences, Rothamsted Research|

### Contributor Roles
|Name|ORCID|Role|Affiliation|
|----|-----|----|-----------|
|Sarah Perryman|<https://orcid.org/0000-0002-0056-2754>|Data Curator|Computational and Analytical Sciences, Rothamsted Research|
|Paul Poulton|<https://orcid.org/0000-0002-5720-064X>|Project Manager|Sustainable Agricultural Sciences, Rothamsted Research|
|Richard Ostler|<https://orcid.org/0000-0002-1434-9495>|Project Leader|Computational and Analytical Sciences, Rothamsted Research|
|Nathalie Castells-Brooke|<https://orcid.org/0000-0003-0168-6254>|Data Manager|Computational and Analytical Sciences, Rothamsted Research|
|Andrew Macdonald|<https://orcid.org/0000-0002-1785-4892>|Project Manager|Sustainable Agricultural Sciences, Rothamsted Research|
|Chris Hall|<None>|Data Collector|Sustainable Agricultural Sciences, Rothamsted Research|
|Margaret Glendining|<https://orcid.org/0000-0002-6466-4629>|Data Curator|Computational and Analytical Sciences, Rothamsted Research|

### Conditions of Use
**Rights Holder**
:    Rothamsted Research

**Licence**
:    This dataset is available under a�Creative Commons Attribution Licence (4.0). [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

**Cite this Dataset**
:    YOU MUST CITE AS:�Perryman S.A.M. & Ostler R.J. (2021). Park Grass hay yields 1965-2018. Electronic Rothamsted Archive, Rothamsted Research 10.23637/rpg-yields1965-2018

**Conditions of Use**
:    Rothamsted relies on the integrity of users to ensure that Rothamsted Research receives suitable acknowledgment as being the originators of these data. This enables us to monitor the use of each dataset and to demonstrate their value. Please send us a link to any publication that uses this Rothamsted data.

### Funding

**Funder name**
:    [Biotechnology and Biological Sciences Research Council](http://dx.doi.org/10.13039/501100000268)

**Award**
:    BBS/E/C/00005189 - The Rothamsted Long-Term Experiments including Sample Archive and e-RA database

**Award info**
:    [http://dx.doi.org/10.13039/501100000268](Biotechnology and Biological Sciences Research Council)

**Funder name**
:    [Biotechnology and Biological Sciences Research Council](http://dx.doi.org/10.13039/501100000268)

**Award**
:    BBS/E/C/000J0300 - The Rothamsted Long - Term Experiments - National Capability

**Award info**
:    [http://dx.doi.org/10.13039/501100000268](Biotechnology and Biological Sciences Research Council)


### Supplementary materials

|Resource|link|description|
|-------------|------------|-----------|
|Experiment plan and treatments|[https://doi.org/10.23637/rpg5-plan1965-01](https://doi.org/10.23637/rpg5-plan1965-01)|Experimental plan for Park Grass experiment 1965-2018, showing plot numbers, layout and treatments. |
|Related dataset|[https://doi.org/10.23637/KeyRefOAPGsoilpH](https://doi.org/10.23637/KeyRefOAPGsoilpH)|Dataset describing Park Grass soil pH 1856-2011|
|Related dataset|[https://doi.org/10.23637/KeyRefOAPGspecies](https://doi.org/10.23637/KeyRefOAPGspecies)|Dataset describing Park Grass species numbers 1856-2011|
|Related dataset|[https://doi.org/10.23637/rpg5-LimeTreats-01](https://doi.org/10.23637/rpg5-LimeTreats-01)|Dataset describing the lime treatments applied to Park Grass sub-plots 1865-2021|
|Related publication|[https://doi.org/10.23637/ERADOC-1-34633](https://doi.org/10.23637/ERADOC-1-34633)|Williams, E. D. (1974) "Changes in yield and botanical composition caused by the new liming scheme on Park Grass", Rothamsted Experimental Station report for 1973, Part 2, 67-73|
|Related publication|[https://doi.org/10.1017/S0021859600067290�](https://doi.org/10.1017/S0021859600067290�)|Jenkinson, D. S. , Potts, J. M. , Perry, J. N. , Barnett, V. , Coleman, K. and Johnston, A. E. (1994) "Trends in Herbage Yields over the Last Century on the Rothamsted Long-Term Continuous Hay Experiment",�Journal of Agricultural Science,�122, 365-374|
|Related publication|[https://doi.org/10.1111/ejss.12521](https://doi.org/10.1111/ejss.12521)|Johnston, A. E. and Poulton, P. R. (2018) "The importance of long-term experiments in agriculture: their management to ensure continued crop production and soil fertility; the Rothamsted experience. ",�European Journal of Soil Science,�69, 113-125|
|Related publication|[https://doi.org/doi.org/10.1111/sum.12343](https://doi.org/doi.org/10.1111/sum.12343)|Bowley, H. E. , Mathers, A. W. , Young, S. D. , Macdonald, A. J. , Ander, E. L. , Watts, M. J. , Zhao, F. J. , Mcgrath, S. P. , Crout, N. M. J. and Bailey, E. H. (2017) "Historical trends in iodine and selenium in soil and herbage at the Park Grass Experiment, Rothamsted Research, UK",�Soil Use and Management,�33, 252-262|

### Data Dictionary

###crop_data

####Crop yield data

Data table containing crop yield data for all plots and all treatments, 1965-2018. Includes details of all lime and fertilizer treatments applied. 

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|site|Site Name|string|default|http://schema.org/name|Rothamsted|
|plot_id|Plot ID|string|default|http://purl.obolibrary.org/obo/STATO_0000447|Fully qualified plot identifier|
|plot|Whole plot ID|string|default|http://purl.obolibrary.org/obo/STATO_0000447|The original scheme plot number. In 1903 most whole plots had been split in half with the southern half receiving lime. In 1965 limed and unlimed half plots were split again halved on their North-South axis to give the 4 plots labelled a, b, c & d. Additionally some plots were split on their East-West axis. Refer to the reference for complete details of plot split histories. Plots 5 and 6c & d are microplots and not used in the yields experiment.|
|split_plot|Sub sub-plot ID|string|default|http://purl.obolibrary.org/obo/STATO_0000449|The sub-sub-plot number; original plots subsequently split. Since 1990, plots 9 and 14 have been divided into 9-1 &  9-2 and 14-1 & 14-2. Since 1995, plot 13 has been split into 13-1 & 13-2. Since 1996, plot 2 has been split into 2-1 & 2-2. Plot 7 was divided into 7-1 and 7-2 in 2013 and P withheld from 7-1. Note; in data file plot-splits are shown with a hyphen '-' whereas in the plan they are indicated by a slash '/' e.g. plot 9-1 is equivalent to 9/1.|
|sub_plot|Sub-plot ID|string|default|http://purl.obolibrary.org/obo/STATO_0000448|Plots were divided into four in 1965; a, b, c and d. Plot 12 was not included in the a,b,c,d set up until 1976, between 1965-1975 it was two half-plots 12ab and 12cd neither of which received lime.  Plot 15 1965-1975 was two halves 15ab (limed) and 15cd (unlimed), it became a,b,c,d sub-plots in 1976-2018. Plots 18/2, 19/1-3 and 20/1-3 were not included in the liming scheme in 1965.|
|harvest_year|Year in which crop harvested|year|default|https://schema.org/Date|The year of cut; range 1965-2018|
|treatments|Treatment combination|integer|default|http://purl.obolibrary.org/obo/STATO_0000264|Full fertiliser treatment combination for plot|
|n_factor_level|N treatment|string|default|http://purl.obolibrary.org/obo/PECO_0007102|Nitrogen fertilizer treatment|
|n_rate|Amount of  fertilizer N applied in that harvest year|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Nitrogen fertilizer amount|
|p_factor_level|P treatment|string|default|http://purl.obolibrary.org/obo/PECO_0007397|Phosphorous fertilizer treatment|
|p_rate|Amount of fertilizer P applied in that harvest year|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Phosphorous fertilizer amount|
|k_factor_level|K treatment|string|default|http://purl.obolibrary.org/obo/PECO_0007293|Potassium fertilizer treatment|
|k_rate|Amount of fertilizer K applied in that harvest year|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Potassium fertilizer amount|
|mg_factor_level|Mg treatment|string|default|http://purl.obolibrary.org/obo/PECO_0007288|Magnesium fertilizer treatment|
|mg_rate|Amount of fertilizer Mg applied in that harvest year|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Magnesium fertilizer amount|
|na_factor_level|Na treatment|string|default||Sodium fertilizer treatment|
|na_rate|Amount of  fertilizer Na applied in that harvest year|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Sodium fertilizer amount|
|si_factor_level|Si treatment|string|default|http://purl.obolibrary.org/obo/PECO_0007235|Silicon fertilizer treatment, applied as  450kg sodium silicate, which contains 135 kgSi|
|si_rate|Amount of  fertilizer Si applied in that harvest year|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Silicon fertilizer amount|
|liming_factor_level|Lime treatment|string|default|http://aims.fao.org/aos/agrovoc/c_200|Whether lime applied or not|
|liming_rate|Amount of lime applied|number|default|https://schema.org/Date|The amount of lime applied as calculated to produce required pH pf sub plot a, b, c. The amounts of lime varied in order to maintain the required pH of sub plot (pH 7, 6 and 5 for a, b, c respectively). The years and amounts applied per application are included in the dataset and in related lime treatments publication|
|fym_factor_level|FYM treatment|string|default|http://aims.fao.org/aos/agrovoc/c_2810|Farm yard manure fertilizer treatment|
|fym_rate|Amount of FYM applied|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Farm yard manure fertilizer amount|
|fm_factor_level|Fish meal treatment|string|default|http://aims.fao.org/aos/agrovoc/c_2925|Fish meal fertilizer treatment; applied until 1999|
|fm_n_rate|Amount of fishmeal applied|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Fish meal fertilizer nitrogen amount|
|pm_factor_level|Poultry manure treatment|string|default|http://purl.obolibrary.org/obo/AGRO_00000080|Poultry manure fertilizer treatment; applied since 2003|
|pm_n_rate|Amount of poultry manure applied|number|default|http://purl.obolibrary.org/obo/AGRO_00010017|Poultry manure fertilizer nitrogen amount|
|harvest_area|Area harvested|number|default|http://aims.fao.org/aos/agrovoc/c_330588|Area of plot harvested; range 0.00039 - 0.00775|
|start_cut_1|First cut harvest date start|date|default|http://aims.fao.org/aos/agrovoc/c_29464|Start date of first cut harvest.|
|end_cut_1|First cut harvest date end|date|default|http://aims.fao.org/aos/agrovoc/c_29464|End date of first cut harvest.|
|start_cart_cut_1|First cut carting date start|date|default||Start date of first cut produce removal from field.|
|end_cart_cut_1|First cut carting date end|date|default||End date of first cut produce removal from field.|
|yield_dry_matter_cut_1|First cut forage dry matter yield|number|default|http://aims.fao.org/aos/agrovoc/c_10176|Yield at 100% DM dry matter for first cut.|
|start_cut_2|Second cut harvest date start|date|default|http://aims.fao.org/aos/agrovoc/c_29464|Start date of second cut harvest|
|end_cut_2|Second cut harvest date end|date|default|http://aims.fao.org/aos/agrovoc/c_29464|End date of second cut harvest|
|start_cart_cut_2|Second cut carting date start|date|default||Start date of second cut produce removal from field|
|end_cart_cut_2|Second cut carting date end|date|default||End date of second cut produce removal from field|
|yield_dry_matter_cut_2|Second cut forage dry matter yield|number|default|http://aims.fao.org/aos/agrovoc/c_10176|Yield at 100% DM dry matter for second cut.|
|note|Note|integer|default||Whether notes are applied or not|


###fm_factor_data

####FM treatment factor level descriptions

FM treatments applied 1965-2002; this describes the fish meal treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied; applied until 1999, then replaced by poultry manure (PM)|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###fym_factor_data

####FYM treatment factor level descriptions

FYM treatments applied 1965-2018; this describes the farm yard manure treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###k_factor_data

####K treatment factor level descriptions

K treatments applied 1965-2018; this describes the potassium treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year.|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###liming_factor_data

####Liming treatment factor level descriptions

Describes the different liming treatment factors, showing the total amounts applied over the experiment required to produce desired pH levels for different sub-plots a-d.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###mg_factor_data

####Mg treatment factor level descriptions

Mg treatments applied 1965-2018; this describes the magnesium treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year.|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###n_factor_data

####N treatment factor level descriptions

N treatments applied 1965-2018; this describes the nitrogen treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year.|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied; as either ammonium sulphate or sodium nitrate - N2 and N*2 last applied 1989|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###na_factor_data

####Na treatment factor level descriptions

Na treatments applied 1965-2018; this describes the sodium treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year.|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###notes_data

####Notes

Additional explanatory notes for records in the crop_data table

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|note_id|Note identification|integer|default||Note number|
|description|Description|string|default|http://schema.org/description|Additional explanatory notes for records in the crop_data_table|


###p_factor_data

####P treatment factor level descriptions

P treatments applied 1965-2018; this describes the phosphorous treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year; 17kg since 2017, previously 35kg|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###pm_factor_data

####PM treatment factor level descriptions

PM treatments applied 2003-2018; this describes the poultry manure treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied; applied since 2003|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|


###si_factor_data

####Si treatment factor level descriptions

Si treatments applied 1965-2018; this describes the silicon treatment factors.

|Name|Title|Type|format|rdfType|Description|
|----|-----|----|------|-------|-----------|
|description|Description|string|default|http://schema.org/description|Description of the factor level, whether the treatment applied or not|
|years|Years of treatment|string|default||Years in which the treatment factor is applied|
|treatment_factor|Treatment factor|string|default|http://schema.org/name|Name for the treatment factor|
|treatment_factor_rdfType|Treatment factor rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the treatment factor|
|factor_level_name|Name of treatment factor level|string|default|http://schema.org/name|Name of the factor level|
|amount|Amount applied that harvest year|number|default|http://schema.org/amount|Amount of  treatment factor level applied per hectare per year.|
|amount_unit|factor level unit|string|default|http://schema.org/unitText|Units of treatment applied|
|frequency|Treatment frequency|string|default|https://schema.org/frequency|Frequency of application of treatment|
|treatment_form|Treatment form|string|default|http://schema.org/name|Chemical form of the treatment applied|
|treatment_form_rdfType|Treatment form rdfType|string|uri|http://purl.obolibrary.org/obo/OBI_0000750|URI for the chemical form of treatment|

