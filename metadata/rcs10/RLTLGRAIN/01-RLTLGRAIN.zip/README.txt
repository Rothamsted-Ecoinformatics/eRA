
Rothamsted long-term liming experiment grain mineral composition
================================================================

[https://doi.org/10.23637/rcs10-rltlgrain-01](10.23637/wcs10-wtlgrain-01)

**Version**
:    1

**Published**
:    2021

**Publisher**
:    Electronic Rothamsted Archive, Rothamsted Research

**Keywords**
:    Rothamsted Research, barley, long term experiments, liming, phosphorous, soil pH, wheat, mineral content, trace elements, oats

YOU MUST CITE AS:�Jordan-Meille, L., Holland, J. E. McGrath, S. P., Glendining, M. J., Thomas, C. L. and Heafele, S. M.  (2021). Rothamsted long-term liming experiment grain mineral composition. Electronic Rothamsted Archive, Rothamsted Research 10.23637/rcs10-rltlgrain-01

## Description
*Note* the included Excel file: _*01-RothLTliming-grain.xlsx*_ contains the same data as the below CSV files. The Excel file contains each of the below CSV files as an Excel worksheet and is provided for users who prefer Excel over CSV.
### Contents

|File|Dataset Name|Description|
|----|------------|-----------|
|grain_data.csv|Grain mineral data|The main data table containing grain mineral concentrations in barley, oats and wheat, 1978, 1981 and 1995. Includes treatments and crop yields. |
|crop_types_data.csv|Crop types|List of crops grown with Latin names and AGROVOC concepts.|
|liming_factor_data.csv|Liming treatment factor level descriptions|Describes the different liming treatment factor levels used, showing the total amounts applied over the experiment. |
|p_factor_data.csv|P treatment factor level descriptions|Describes the different P treatment factor levels used: Period 1 (1962-1980) when two P rates (0 and P) were applied annually; Period 2 (1981-1996) when four P treatments (P0, P1, P2 and P3) were applied three or four times only.  |
|k_factor_data.csv|K treatment factor level descriptions|Describes the different K treatment factor levels used, 1962-1978|
|mn_factor_data.csv|Mn treatment factor level descriptions|Describes the different Mn treatment factor levels used, 1987-1990|
|notes_data.csv|Notes|Additional explanatory notes for records in the crop_data table|

### Abstract
The experiment tests the effects of four different amounts of lime (creating a soil pH range for approximately 4.5 to 7.5) with and without fertilizer P, on the grain mineral compostion of three arable crops. The site is a silty clay loam soil at Rothamsted Experimental Farm, from 1962-1996. There was a parallel experiment on a sandy loam soil at Woburn Experimental Farm.
### Methods
Grain mineral composition was determined, in 2019 and 2020, on archived ground samples grown in 1978 (barley), 1981 (oats) and 1995 (wheat). Macro-nutrients (Ca, K, Mg, Na, P, S) and Al, Fe and Ti were determined by open tube digestion with HNO3/HClO4 and measured with ICP-OES. Micro-nutrients and trace elements (As, Cd, Co, Cr, Cu, Mn, Mo, Ni, Pb, Se, and Zn) were determined with microwave digestion with HNO3/H2O2, then measured with ICP-MS.
### Provenance
The original archived grain samples were stored in the Rothamsted Sample Archive. The chemical analysis was carried out in the Analytical Unit of Rothamsted Research in 2019 and 2020.

### Authors
|Name|ORCID|Affiliation|
|----|-----|-----------|
|Lionel Jordan_Meille|<https://orcid.org/0000-0003-1169-7002>|Bordeaux Sciences Agro|
|Jonathan Holland|<https://orcid.org/0000-0001-6661-0168>|The James Hutton Institute|
|Steve McGrath|<https://orcid.org/0000-0003-0952-8947>|Sustainable Agricultural Sciences, Rothamsted Research|
|Margaret Glendining|<https://orcid.org/0000-0002-6466-4629>|Computational and Analytical Sciences, Rothamsted Research|
|Cathy Thomas|<https://orcid.org/0000-0002-6320-9923>|Sustainable Agricultural Sciences, Rothamsted Research|
|Stephan Haefele|<https://orcid.org/0000-0003-0389-8373>|Sustainable Agricultural Sciences, Rothamsted Research|

### Contributor Roles
|Name|ORCID|Role|Affiliation|
|----|-----|----|-----------|
|Nathalie Castells-Brooke|<https://orcid.org/0000-0003-0168-6254>|Data Manager|Computational and Analytical Sciences, Rothamsted Research|
|Margaret Glendining|<https://orcid.org/0000-0002-6466-4629>|Data Curator|Computational and Analytical Sciences, Rothamsted Research|
|Sarah Perryman|<https://orcid.org/0000-0002-0056-2754>|Data Curator|Computational and Analytical Sciences, Rothamsted Research|
|Cathy Thomas|<https://orcid.org/0000-0002-6320-9923>|Data Collector|Sustainable Agricultural Sciences, Rothamsted Research|
|Steve McGrath|<https://orcid.org/0000-0003-0952-8947>|Project Manager|Sustainable Agricultural Sciences, Rothamsted Research|
|Jonathan Holland|<https://orcid.org/0000-0001-6661-0168>|Researcher|The James Hutton Institute|
|Richard Ostler|<https://orcid.org/0000-0002-1434-9495>|Project Manager|Computational and Analytical Sciences, Rothamsted Research|
|Stephan Haefele|<https://orcid.org/0000-0003-0389-8373>|Project Manager|Sustainable Agricultural Sciences, Rothamsted Research|
|Lionel Jordan_Meille|<https://orcid.org/0000-0003-1169-7002>|Researcher|Bordeaux Sciences Agro|
|Mark Durenkamp|<https://orcid.org/0000-0002-2195-1855>|Data Collector|Computational and Analytical Sciences, Rothamsted Research|
|Chloe Garwood|<https://orcid.org/0000-0002-2831-6854>|Data Collector|Computational and Analytical Sciences, Rothamsted Research|
|Ruth Skilton|<None>|Data Collector|Computational and Analytical Sciences, Rothamsted Research|

### Conditions of Use
**Rights Holder**
:    Rothamsted Research

**Licence**
:    This dataset is available under a�Creative Commons Attribution Licence (4.0). [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

**Cite this Dataset**
:    YOU MUST CITE AS:�Jordan-Meille, L., Holland, J. E. McGrath, S. P., Glendining, M. J., Thomas, C. L. and Heafele, S. M.  (2021). Rothamsted long-term liming experiment grain mineral composition. Electronic Rothamsted Archive, Rothamsted Research 10.23637/rcs10-rltlgrain-01

**Conditions of Use**
:    Rothamsted relies on the integrity of users to ensure that Rothamsted Research receives suitable acknowledgment as being the originators of these data. This enables us to monitor the use of each dataset and to demonstrate their value. Please send us a link to any publication that uses this Rothamsted data.

### Funding

**Funder name**
:    [Biotechnology and Biological Sciences Research Council](http://dx.doi.org/10.13039/501100000268)

**Award**
:    BBS/E/C/000J0300 - The Rothamsted Long - Term Experiments - National Capability

**Award info**
:    [http://dx.doi.org/10.13039/501100000268](Biotechnology and Biological Sciences Research Council)


### Supplementary materials

|Resource|link|description|
|-------------|------------|-----------|
|Holland et al, 2019|[https://doi.org/10.1016/j.eja.2019.02.016](https://doi.org/10.1016/j.eja.2019.02.016)|Paper describing yield response of all crops grown, 1962-1996|
|Bolton, 1971|[https://doi.org/10.23637/ERADOC-1-34802](https://doi.org/10.23637/ERADOC-1-34802)|Paper describing setting up the experiment and results from the early years of the experiment|
|Bolton, 1977a|[https://doi.org/10.1017/S0021859600027222](https://doi.org/10.1017/S0021859600027222)|Paper describing liming response of potatoes and oats to P, K and Mg fertilizer factor levels|
|Rothamsted long-term liming experiment plans 1962-1996|[https://doi.org/10.23637/rcs10-Plans](https://doi.org/10.23637/rcs10-Plans)|Standard experimental plans for Rothamsted long-term liming experiment 1962-1996, showing plot numbers, layout and treatments. |
|Rothamsted long-term liming experiments lime and fertilizer treatments 1962-1996|[https://doi.org/10.23637/rcs10-Treatments-01](https://doi.org/10.23637/rcs10-Treatments-01)|Summary of the lime and fertilizer treatments applied to the long-term liming experiments at Rothamsted, 1962-1996|
|Rothamsted long-term liming experiment crop yields 1962-1996|[https://doi.org/10.23637/rcs10-rltlyields-01](https://doi.org/10.23637/rcs10-rltlyields-01)|Details of crop yields, lime and fertilizer treatments and cropping details for the Rothamsted long-term liming experiment 1962-1996|
|Woburn long-term liming experiment grain mineral compostion |[https://doi.org/10.23637/wcs10-wtlgrain-01](https://doi.org/10.23637/wcs10-wtlgrain-01)|Grain element concentrations of barley, oats and wheat on the Woburn long-term liming experiment, 1978, 1981 and 1995|
